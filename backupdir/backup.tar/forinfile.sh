file="cities"
for state in `cat $file`
do
echo "Visit beautiful $file“
done
